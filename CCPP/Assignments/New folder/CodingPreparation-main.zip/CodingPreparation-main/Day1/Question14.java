import java.util.Scanner;
class Question14{
	public static void main(String[] args){
		
		int a = 10;
		int b = 20;
		
		while(a!=0){
			
			a--;
			b++;
		}
		
		System.out.println("sum of numbers : " +b);
		
	}
}